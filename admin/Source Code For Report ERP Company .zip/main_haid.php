<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.radixtouch.com/templates/admin/atrio/source/lighthr/pages/employee/add-employee.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 19 Dec 2021 09:09:26 GMT -->
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Admin - HR and Company Management Admin Template</title>
    <!-- Favicon-->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <link href="assets/css/form.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body class="light">
    <!-- Page Loader -->
   <!--  <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="assets/images/loading.png" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="#" onClick="return false;" class="navbar-toggle collapsed" data-bs-toggle="collapse"
                    data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="#" onClick="return false;" class="bars"></a>
                <a class="navbar-brand" href="index.html">
                    <img src="assets/images/logo.png" alt="" />
                    <span class="logo-name">Admin</span>
                </a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="float-start">
                    <li>
                        <a href="#" onClick="return false;" class="sidemenu-collapse">
                            <i data-feather="menu"></i>
                        </a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <!-- Full Screen Button -->
                    <li class="fullscreen">
                        <a href="javascript:;" class="fullscreen-btn">
                            <i class="fas fa-expand"></i>
                        </a>
                    </li>
                    <!-- #END# Full Screen Button -->
                    <!-- #START# Notifications-->
                  
                    <!-- #END# Notifications-->
                    <li class="dropdown user_profile">
                        <div class="dropdown-toggle" data-bs-toggle="dropdown">
                            <img src="assets/images/user.jpg" alt="user">
                        </div>
                        <ul class="dropdown-menu pullDown">
                            <li class="body">
                                <ul class="user_dw_menu">
                                   
                                    <li>
                                        <a href="logout.php" onClick="return false;">
                                            <i class="material-icons">power_settings_new</i>Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Tasks -->
                    <li class="float-end">
                        <a href="#" onClick="return false;" class="js-right-sidebar" data-close="true">
                            <i class="fas fa-cog"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <div>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="sidebar-user-panel active">
                        <div class="user-panel">
                            <div class=" image">
                                <img src="assets/images/usrbig.jpg" class="user-img-style" alt="User Image" />
                            </div>
                        </div>
                        <div class="profile-usertitle">
                            <div class="sidebar-userpic-name"> Admin </div>
                            <div class="profile-usertitle-job ">Manager </div>
                        </div>
                    </li>
                    <li class="header">-- Main</li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="monitor"></i>
                            <span>Home</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="index.html">Dashboard 1</a>
                            </li>
                            <li>
                                <a href="dashboard/dashboard2.html">Dashboard 2</a>
                            </li>
                        </ul>
                    </li>
                    <li class="active">
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="users"></i>
                            <span>Employees</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="all-employees.html">All Employee</a>
                            </li>
                            <li class="active">
                                <a href="add-employee.html">Add Employee</a>
                            </li>
                            <li>
                                <a href="edit-employee.html">Edit Employee</a>
                            </li>
                        </ul>
                    </li>
                   <!--  <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="briefcase"></i>
                            <span>Projects</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="projects/all-projects.html">All Projects</a>
                            </li>
                            <li>
                                <a href="projects/add-project.html">Add Project</a>
                            </li>
                            <li>
                                <a href="projects/edit-project.html">Edit Project</a>
                            </li>
                        </ul>
                    </li> -->
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="book-open"></i>
                            <span>Attendance</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="attendance/today-attend.html">Today Attendance</a>
                            </li>
                            <li>
                                <a href="attendance/emp-attend.html">Employee Attendance</a>
                            </li>
                        </ul>
                    </li>
                    <!-- <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="user"></i>
                            <span>Clients</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="clients/all-clients.html">All Clients</a>
                            </li>
                            <li>
                                <a href="clients/add-client.html">Add Client</a>
                            </li>
                            <li>
                                <a href="clients/edit-client.html">Edit Client</a>
                            </li>
                        </ul>
                    </li> -->
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="clipboard"></i>
                            <span>Leave Management</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="leave/all-leave.html">All Leave Request</a>
                            </li>
                            <li>
                                <a href="leave/leave-balance.html">Leave Balance</a>
                            </li>
                            <li>
                                <a href="leave/add-leave.html">New Leave Request</a>
                            </li>
                            <li>
                                <a href="leave/edit-leave.html">Edit Leave Request</a>
                            </li>
                            <li>
                                <a href="leave/leave-type.html">Leave Types</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="headphones"></i>
                            <span>Holidays</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="holiday/all-holidays.html">All Holidays</a>
                            </li>
                            <li>
                                <a href="holiday/add-holiday.html">Add Holiday</a>
                            </li>
                            <li>
                                <a href="holiday/edit-holiday.html">Edit Holiday</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="book"></i>
                            <span>Accounts</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="accounts/income.html">Income</a>
                            </li>
                            <li>
                                <a href="accounts/expense.html">Expenses</a>
                            </li>
                            <li>
                                <a href="accounts/invoice.html">Invoices</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="trello"></i>
                            <span>Departments</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="departments/all-departments.html">All Departments</a>
                            </li>
                            <li>
                                <a href="departments/add-department.html">Add Department</a>
                            </li>
                            <li>
                                <a href="departments/edit-department.html">Edit Departments</a>
                            </li>
                        </ul>
                    </li>
                   <!--  <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="dollar-sign"></i>
                            <span>Payroll</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="payroll/payslip.html">Payslip</a>
                            </li>
                            <li>
                                <a href="payroll/employee-salary.html">Employee Salary</a>
                            </li>
                        </ul>
                    </li> -->
                   <!--  <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="command"></i>
                            <span>Job</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="job/add-job.html">Add Job</a>
                            </li>
                            <li>
                                <a href="job/requirement-list.html">Requirements</a>
                            </li>
                            <li>
                                <a href="job/applicant-list.html">Applicant List</a>
                            </li>
                        </ul>
                    </li> -->
                 <!--    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i data-feather="package"></i>
                            <span>Consultancy</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="consultancy/all-consultancy.html">All Consultancy</a>
                            </li>
                            <li>
                                <a href="consultancy/add-consultancy.html">Add Consultancy</a>
                            </li>
                            <li>
                                <a href="consultancy/edit-consultancy.html">Edit Consultancy</a>
                            </li>
                        </ul>
                    </li> -->
                   

                   
                   
                   
                   
                   
             
                   
                </ul>
            </div>
            <!-- #Menu -->
        </aside>